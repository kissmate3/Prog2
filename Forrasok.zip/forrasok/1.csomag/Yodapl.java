class Yodapl{

public static void main(String args[]){
    String peldastring = null;
    if (peldastring.equals("pelda")){
          System.out.println("Pelda kod");
          }
    }
}      
