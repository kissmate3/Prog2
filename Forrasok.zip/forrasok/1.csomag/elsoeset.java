class elsoeset{
    public static void main(String args []){
    Integer x=120;
    Integer t=120;
    
    while (x <= t && x >= t && t != x)
        System.out.println("A feltetel nem teljesul");
    }
}      
