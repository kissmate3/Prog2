class masodikeset{
    public static void main(String args []){
    Integer x=140;
    Integer t=140;
    
    while (x <= t && x >= t && t != x)
        System.out.println("Vegtelen ciklus");
    }
}   
