import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

public class FullS extends JFrame{
	static JFrame F = new FullS();
	
	public FullS()
	{
		setUndecorated(true);
		setSize(Toolkit.getDefaultToolkit().getScreenSize());
		setVisible(true);
	}
	public void paint(Graphics g) {
   		 Dimension d = this.getPreferredSize();
    		int fontSize = 75;

    		g.setFont(new Font("TimesRoman", Font.PLAIN, fontSize));
    	 
    		g.setColor(Color.black);
    
    		g.drawString("Szia full screen", 560, 540);
  	}
	
	public static void main(String[] args)
	{	
	
	}
}
