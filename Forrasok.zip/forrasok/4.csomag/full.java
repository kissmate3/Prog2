import java.awt.*;
import javax.swing.JFrame;

public class full extends JFrame{
	public static void main(String[] args){
		
		DisplayMode dm = new DisplayMode(800,600,16, DisplayMode)	

	}
}
